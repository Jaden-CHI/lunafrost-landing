---
name: TaskSnap
colors:
  surface: '#13121b'
  surface-dim: '#13121b'
  surface-bright: '#3a3841'
  surface-container-lowest: '#0e0d15'
  surface-container-low: '#1c1b23'
  surface-container: '#201f27'
  surface-container-high: '#2a2932'
  surface-container-highest: '#35343d'
  on-surface: '#e5e0ed'
  on-surface-variant: '#c8c4d7'
  inverse-surface: '#e5e0ed'
  inverse-on-surface: '#312f38'
  outline: '#928fa0'
  outline-variant: '#474554'
  surface-tint: '#c6bfff'
  primary: '#c6bfff'
  on-primary: '#2700a0'
  primary-container: '#8c80ff'
  on-primary-container: '#22008e'
  inverse-primary: '#5747d3'
  secondary: '#40efb7'
  on-secondary: '#003827'
  secondary-container: '#00d29c'
  on-secondary-container: '#00543d'
  tertiary: '#ffb86e'
  on-tertiary: '#492900'
  tertiary-container: '#ce7e17'
  on-tertiary-container: '#402300'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e4dfff'
  primary-fixed-dim: '#c6bfff'
  on-primary-fixed: '#150066'
  on-primary-fixed-variant: '#3f29bb'
  secondary-fixed: '#54fdc4'
  secondary-fixed-dim: '#27e0a9'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#00513b'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#ffb86e'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#693c00'
  background: '#13121b'
  on-background: '#e5e0ed'
  surface-variant: '#35343d'
typography:
  display:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 16px
  gutter: 12px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

The design system is built upon a foundation of "Quiet Power"—a philosophy that prioritizes deep focus and executive-level sophistication. It targets high-performing professionals who require a workspace that feels less like a utility and more like a high-end instrument. 

The aesthetic is a refined hybrid of **Minimalism** and **Glassmorphism**. By stripping away unnecessary ornamentation and utilizing translucent layers, the system creates a sense of spatial depth that mimics a physical desk at night. The emotional response is intended to be one of calm clarity; the dark, deep navy backgrounds reduce eye strain, while the lavender glows guide the user's attention to what matters most. Every interaction should feel buttery and intentional, reinforcing the premium nature of the task management experience.

## Colors

The palette for the design system is anchored in "Deep Space" tones to maximize contrast and legibility without harshness. 

- **Primary Accent:** The Lavender (#7C6EFA) is used sparingly for high-intent actions and active states. It should always be accompanied by a subtle 15% opacity outer glow to simulate light emission.
- **Success State:** Mint Green (#06D6A0) provides a refreshing, high-visibility contrast for completed tasks and positive feedback.
- **Neutral Scales:** The background and surface colors utilize a navy-tinted slate rather than pure black to maintain a sense of luxury. Borders are kept extremely low-contrast (#2A3140) to define areas without cluttering the visual field.

## Typography

This design system exclusively utilizes **Inter** to leverage its exceptional legibility and neutral, systematic character. 

The typographic hierarchy is tight, avoiding extreme size variations to maintain the minimal Chrome extension footprint. Weights are used strategically: **600 (Semi-Bold)** for structural headers, **500 (Medium)** for interactive labels and buttons, and **400 (Regular)** for standard body text. To enhance the premium feel, display headings use a slightly negative letter spacing, while small labels use increased tracking to ensure readability at small scales within the extension popup.

## Layout & Spacing

Because the design system is tailored for a Chrome extension, it employs a **Fixed Grid** model optimized for a standard popup width (360px to 400px). 

The layout relies on a 4px base unit to create a rhythmic, structured flow. Margins are kept generous (16px) to prevent the UI from feeling cramped against the browser edges. Vertical rhythm is established through "Stack" tokens, ensuring consistent separation between task groups and card elements. Elements should prioritize vertical scrolling with pinned headers and footers to maintain context.

## Elevation & Depth

Depth in this design system is achieved through **Glassmorphism** and tonal layering rather than traditional drop shadows. 

1.  **The Base:** The bottom-most layer is the solid Deep Navy (#0D0F14).
2.  **Surfaces:** Cards and containers use a semi-transparent Dark Slate (#161B22 at 80% opacity) with a `backdrop-filter: blur(20px)`.
3.  **Borders:** Instead of heavy shadows, use a 1px solid border (#2A3140). For active or "elevated" states, the border color may shift slightly toward the primary lavender at 30% opacity.
4.  **Glows:** Active elements (like the current task or a focused input) utilize a `box-shadow: 0 0 15px rgba(124, 110, 250, 0.15)` to create a soft "neon" effect that feels modern and high-tech.

## Shapes

The design system utilizes a progressive rounding scale to differentiate between UI hierarchy:

- **Small (8px):** Used for interactive components like buttons, checkboxes, and tags.
- **Medium (12px):** The standard for task cards and inner containers.
- **Large (16px):** Reserved for the main extension container and modal overlays.

All icons must follow the **Lucide** style: 1.5px or 2px stroke weight with rounded caps and joins, ensuring they harmonize with the soft corners of the container system.

## Components

### Buttons
Primary buttons use a solid Lavender (#7C6EFA) fill with white text and a soft lavender glow. Secondary buttons use a ghost style: a 1px border (#2A3140) with a subtle background hover state (#161B22).

### Task Cards
Cards are the primary data vehicle. They feature the Dark Slate background with 12px rounded corners and a 1px subtle border. On hover, the border color should subtly transition to a brighter gray or dim lavender.

### Inputs
Input fields are minimal, featuring only a bottom border or a very subtle container fill. Upon focus, the border transitions to Lavender, accompanied by the signature 20px backdrop blur and a soft outer glow.

### Checkboxes
Checkboxes are circular to contrast with the rectangular cards. When checked, they transition from a hollow border to a solid Mint Green (#06D6A0) fill with a white checkmark, signifying completion through a distinct color shift.

### Chips & Tags
Used for task categories. These should have a background opacity of 10% of the text color (e.g., a Lavender tag has a #7C6EFA background at 0.1 alpha) to keep the UI light and airy.